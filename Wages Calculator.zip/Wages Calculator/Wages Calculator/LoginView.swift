import SwiftUI
import FirebaseAuth

struct LoginView: View {
    @Binding var isAuthenticated: Bool
    
    @State private var email = ""
    @State private var password = ""
    @State private var wrongUsername = 0
    @State private var wrongPassword = 0
    @State private var showingCreateAccount = false
    
    var body: some View {
        ZStack {
            // Set the background color and overlay concentric circles for a decorative effect.
            Color.blue.ignoresSafeArea()
            Circle().scale(1.7).foregroundColor(.white.opacity(0.15))
            Circle().scale(1.35).foregroundColor(.white)

            VStack {
                Text("Login")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(Color.black)
                    .padding()

                TextField("Email", text: $email)
                    .autocapitalization(.none)
                    .keyboardType(.emailAddress)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .foregroundColor(Color.black)
                    .border(Color.red, width: CGFloat(wrongUsername))

                SecureField("Password", text: $password)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .foregroundColor(Color.black)
                    .border(Color.red, width: CGFloat(wrongPassword))

                Button("Login") {
                    authenticateUser(email: email, password: password)
                }
                .foregroundColor(.white)
                .frame(width: 300, height: 50)
                .background(Color.blue)
                .cornerRadius(10)

                Button("Create Account") {
                    self.showingCreateAccount = true
                }
                .sheet(isPresented: $showingCreateAccount) {
                    CreateAccountView(isPresented: self.$showingCreateAccount, isAuthenticated: <#Binding<Bool>#>)
                }
            }
        }
    }

    // Move your function here, outside of the body
    func authenticateUser(email: String, password: String) {
        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
            if let error = error {
                print("Error logging in: \(error.localizedDescription)")
                self.wrongUsername = 1
                self.wrongPassword = 1
            } else {
                wrongUsername = 0
                wrongPassword = 0
                isAuthenticated = true
                
                
            }
        }
    }
}
