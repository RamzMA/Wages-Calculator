//
//  Wages_CalculatorApp.swift
//  Wages Calculator
//
//  Created by Ramz Ahmed on 09/04/2024.
//

import SwiftUI
import Firebase

@main
struct Wages_CalculatorApp: App {
    init(){
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
