// Import the SwiftUI framework for UI development.
import SwiftUI

// Define a struct named ContentView, which conforms to the View protocol. This struct defines the content and layout of the view.
struct ContentView: View {
    // Declare state variables to manage the username, password, and error states. State variables allow the view to react to their changes.
    @State private var email = ""
    @State private var password = ""
    @State private var wrongUsername = 0
    @State private var wrongPassword = 0
    @State private var isAuthenticated = false
    @State private var showingCreateAccount = false

    
    // The body property defines the view's body. SwiftUI will update the body’s content when state variables change.
    var body: some View {
        Group {
            if isAuthenticated {
                // If the user is authenticated, display the MainView and pass the username and a logout closure.
                MainView(email: email) {
                    // Logout action resets authentication state and clears user credentials.
                    self.isAuthenticated = false
                    self.email = ""
                    self.password = ""
                    
                }
            } else {
                // If not authenticated, display the login view.
                loginView
            }
        }
    }

    // Define a computed property for the login view. It uses a NavigationView and ZStack for layout.
    var loginView: some View {
        NavigationView {
            ZStack {
                // Set the background color and overlay concentric circles for a decorative effect.
                Color.blue
                    .ignoresSafeArea()
                Circle()
                    .scale(1.7)
                    .foregroundColor(.white.opacity(0.15))
                Circle()
                    .scale(1.35)
                    .foregroundColor(.white)

                // Use a VStack to arrange the login form elements vertically.
                VStack {
                    // Display a title for the login form.
                    Text("Login")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(Color.black)
                        .padding()

                    // Username input field.
                    TextField("Email", text: $email)
                        .autocapitalization(.none)
                        .keyboardType(.emailAddress)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        .foregroundColor(Color.black)
                        .border(Color.red, width: CGFloat(wrongUsername))


                    // Password input field, obscured for security.
                    SecureField("Password", text: $password)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        .foregroundColor(Color.black)
                        .border(Color.red, width: CGFloat(wrongPassword))

                    // Login button with an action to authenticate the user.
                    Button("Login") {
                        authenticateUser(email: email, password: password)
                    }
                    .foregroundColor(.white)
                    .frame(width: 300, height: 50)
                    .background(Color.blue)
                    .cornerRadius(10)
                    
                    
                    Button("Create Account") {
                        self.showingCreateAccount = true
                    }
                    .sheet(isPresented: $showingCreateAccount) {
                        CreateAccountView(isPresented: self.$showingCreateAccount)
                    }

                }
            }
            .navigationBarHidden(true)
        }
    }

    // Function to authenticate the user. It checks the username and password, and sets the state accordingly.
    func authenticateUser(email: String, password: String) {
        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
            if let error = error {
                print("Error logging in: \(error.localizedDescription)")
                // Handle login error (e.g., update UI to show an error message)
                self.wrongUsername = 1 // You might want to use more meaningful state variables to reflect the error state
                self.wrongPassword = 1
            } else {
                // Login successful, update UI accordingly
                wrongUsername = 0
                wrongPassword = 0
                isAuthenticated = true
            }
        }
    }
}

// Import SwiftUI framework for UI development.
import SwiftUI
import FirebaseAuth

// Define a struct named MainView, which conforms to the View protocol. This struct is for the authenticated view.
struct MainView: View {
    // Properties for the username, logout action, and an array representing days of the week.
    var email: String
    var logout: () -> Void
    private let daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    
    // State variables to manage hours worked and total earnings. These are dynamic and can trigger UI updates.
    @State private var hoursWorked: [String: String] = ["Monday": "", "Tuesday": "", "Wednesday": "", "Thursday": "", "Friday": "", "Saturday": "", "Sunday": ""]
    @State private var totalEarnings: Double = 0.0

    // The body property defines the layout of the view. It uses a ScrollView for scrollable content.
    var body: some View {
        ScrollView {
            // Arrange content in a vertical stack.
            VStack(alignment: .leading) {
                // Create a row for each day of the week for hour input.
                ForEach(daysOfWeek, id: \.self) { day in
                    HStack {
                        Text(day)
                            .font(.headline)
                        
                        // Input field for hours worked with a custom binding to the hoursWorked dictionary.
                        TextField("Hours", text: Binding(
                            get: { self.hoursWorked[day] ?? "" },
                            set: { self.hoursWorked[day] = $0 }
                        ))
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.decimalPad)
                        .frame(width: 100)
                    }
                    .padding(.horizontal)
                }

                // Button to submit data and calculate earnings.
                Button("Submit") {
                    calculateEarnings()
                }
                .foregroundColor(.white)
                .frame(width: 200, height: 50)
                .background(Color.green)
                .cornerRadius(10)
                .padding()

                // Display total earnings if greater than 0.
                if totalEarnings > 0 {
                    Text(String(format: "Total Earnings: $%.2f", totalEarnings))
                        .font(.title)
                        .foregroundColor(Color.primary) // Use adaptive color for different modes.
                        .padding()
                }
                
                // Reset button to clear inputs and earnings.
                Button("Reset") {
                    resetFields()
                }
                .foregroundColor(.white)
                .frame(width: 200, height: 50)
                .background(Color.orange)
                .cornerRadius(10)
                .padding()

                // Logout button to return to the login view.
                Button("Logout") {
                    logout()
                }
                .foregroundColor(.white)
                .frame(width: 200, height: 50)
                .background(Color.red)
                .cornerRadius(10)
                .padding()
            }
            .padding(.top)
        }
        .onTapGesture {
            // Dismiss the keyboard when tapping outside input fields.
            hideKeyboard()
        }
    }

    // Function to reset input fields and earnings to their initial state.
    private func resetFields() {
        for day in daysOfWeek {
            hoursWorked[day] = ""
        }
        totalEarnings = 0.0
    }

    // Function to calculate total earnings based on inputs and special conditions.
    private func calculateEarnings() {
        totalEarnings = daysOfWeek.reduce(0.0) { result, day in
            // Convert hours worked to a double and apply an hourly rate. Special rate for Sundays and adjusted hours for specific conditions.
            let dailyHours = Double(hoursWorked[day] ?? "") ?? 0
            let rate = (day == "Sunday") ? 21.21 : 14.14
            let adjustedHours = (dailyHours == 6) ? 5.5 : (dailyHours == 7) ? 6 : (dailyHours == 8) ? 7 : dailyHours
            return result + (adjustedHours * rate)
        }
    }

    // Function to dismiss the keyboard across the app.
    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

// Provide a preview of ContentView in Xcode.
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



// Ensure you have a ContentView_Previews if you're using Xcode previews
struct CreateAccountView_Previews: PreviewProvider {
    static var previews: some View {
        CreateAccountView(isPresented: .constant(true), isAuthenticated: <#Binding<Bool>#>)
    }
}

