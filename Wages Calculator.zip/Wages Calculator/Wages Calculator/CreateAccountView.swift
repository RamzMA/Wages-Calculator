import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct CreateAccountView: View {
    @Binding var isPresented: Bool
    @State private var email = ""
    @State private var password = ""
    @State private var payPerHour = ""
    @State private var payPerHourSundays = ""
    @Binding var isAuthenticated: Bool

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                TextField("Email", text: $email)
                    .autocapitalization(.none)
                    .keyboardType(.emailAddress)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                TextField("Pay Per Hour", text: $payPerHour)
                    .keyboardType(.decimalPad)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                TextField("Pay Per Hour Sundays", text: $payPerHourSundays)
                    .keyboardType(.decimalPad)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                Button("Create Account") {
                    createAccount(email: email, password: password)
                }
                .padding()
                
                Spacer()
            }
            .navigationBarTitle("Create Account", displayMode: .inline)
            .navigationBarItems(trailing: Button("Cancel") {
                self.isPresented = false
            })
        }
    }

    private func createAccount(email: String, password: String) {
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let error = error {
                print("Error creating account: \(error.localizedDescription)")
            } else {
                if let userId = authResult?.user.uid {
                    let db = Firestore.firestore()
                    db.collection("users").document(userId).setData([
                        "payPerHour": payPerHour,
                        "payPerHourSundays": payPerHourSundays
                    ]) { error in
                        if let error = error {
                            print("Error writing document: \(error)")
                        } else {
                            self.isAuthenticated = true
                            self.isPresented = false
                        }
                    }
                }
            }
        }
    }
}
